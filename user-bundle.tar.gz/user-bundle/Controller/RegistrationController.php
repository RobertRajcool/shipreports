<?php

/*
 * This file is part of the FOSUserBundle package.
 *
 * (c) FriendsOfSymfony <http://friendsofsymfony.github.com/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace FOS\UserBundle\Controller;

use FOS\UserBundle\FOSUserEvents;
use FOS\UserBundle\Event\FormEvent;
use FOS\UserBundle\Event\GetResponseUserEvent;
use FOS\UserBundle\Event\FilterUserResponseEvent;
use Initial\ShippingBundle\Form\RegistrationFormType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use FOS\UserBundle\Model\UserInterface;
use Initial\ShippingBundle\Entity\CompanyDetails;
use  Initial\ShippingBundle\Entity\CompanyUsers;
use Symfony\Component\HttpFoundation\JsonResponse;
use Initial\ShippingBundle\Entity\User;


/**
 * Controller managing the registration
 *
 * @author Thibault Duplessis <thibault.duplessis@gmail.com>
 * @author Christophe Coevoet <stof@notk.org>
 */
class RegistrationController extends Controller
{
    public function registerAction(Request $request)
    {
        $user = $this->getUser();
        if ($user != null) {
        /** @var $formFactory \FOS\UserBundle\Form\Factory\FactoryInterface */
        $formFactory = $this->get('fos_user.registration.form.factory');
        /** @var $userManager \FOS\UserBundle\Model\UserManagerInterface */
        $userManager = $this->get('fos_user.user_manager');
        /** @var $dispatcher \Symfony\Component\EventDispatcher\EventDispatcherInterface */
        $dispatcher = $this->get('event_dispatcher');

        $user = $userManager->createUser();
        $user->setEnabled(true);

        $event = new GetResponseUserEvent($user, $request);
        $dispatcher->dispatch(FOSUserEvents::REGISTRATION_INITIALIZE, $event);

        if (null !== $event->getResponse()) {
            return $event->getResponse();
        }


        $form = $formFactory->createForm();

        $form->setData($user);

        $form->handleRequest($request);
        //getting id from user login//

        $user1 = $this->getUser();
        $userId = $user1->getId();

        $em = $this->getDoctrine()->getManager();


        if ($form->isValid()) {
            $query1 = $em->createQueryBuilder()
                ->select('a.roles')
                ->from('InitialShippingBundle:User', 'a')
                ->where('a.id = :userId')
                ->setParameter('userId', $userId)
                ->getQuery()
                ->getResult();
            $role = $query1[0]['roles'][0];
            if ($role == 'ROLE_ADMIN') {
                $companyid = $em->createQueryBuilder()
                    ->select('a.id')
                    ->from('InitialShippingBundle:CompanyDetails', 'a')
                    ->leftjoin('InitialShippingBundle:User', 'b', 'WITH', 'a.adminName = b.username')
                    ->where('b.id = :userId')
                    ->setParameter('userId', $userId)
                    ->getQuery()
                    ->getSingleScalarResult();
                $newcompanyid = $em->getRepository('InitialShippingBundle:CompanyDetails')->findOneBy(array('id' => $companyid));
                $user->setCompanyid($newcompanyid);
            }

            $event = new FormEvent($form, $request);

            $dispatcher->dispatch(FOSUserEvents::REGISTRATION_SUCCESS, $event);
            $role1 = $request->request->get('privileges');
            //$params = $request->request->get('fos_user_registration_form');
            //$Mobile = $params['mobile'];
            // $name = $params['fullname'];


            //$user = new User();
            $user->setRoles(array($role1));
            //$user->setmobile($Mobile);
            //$user->setFullname($name);


            // $em->persist($uservalue);
            //$em->flush();


            $userManager->updateUser($user);
            $role = $this->container->get('security.context')->isGranted('ROLE_ADMIN');
            $em = $this->getDoctrine()->getManager();


            $query = $em->createQueryBuilder()
                ->select('a.id')
                ->from('InitialShippingBundle:CompanyDetails', 'a')
                ->leftjoin('InitialShippingBundle:User', 'b', 'WITH', 'a.adminName = b.username')
                ->where('b.id = :userId')
                ->setParameter('userId', $userId)
                ->getQuery()
                ->getSingleScalarResult();


            return $this->redirectToRoute('fos_user_registration_show');
        }

        return $this->render('FOSUserBundle:Registration:register.html.twig', array(

            'form' => $form->createView(),
        ));
         } else {
         return $this->redirectToRoute('fos_user_security_login');
          }

     }

    public function showallAction(Request $request)
    {
        $user = $this->getUser();
        if ($user != null) {
        $em = $this->getDoctrine()->getManager();
        $user1 = $this->getUser();
        $userId = $user1->getId();
        $query = $em->createQueryBuilder()
            ->select('a.roles')
            ->from('InitialShippingBundle:User','a')
            ->where('a.id = :userId')
            ->setParameter('userId',$userId)
            ->getQuery()
            ->getResult();
        /*  $getalluser = $em->createQueryBuilder()
              ->select('a.roles')
              ->from('InitialShippingBundle:User','a')
              ->groupby('a.roles')
              ->getQuery()
              ->getResult();
          $findrolearray=array();
          for($i=0;$i<count($getalluser);$i++)
          {
              $findrole=$getalluser[$i]['roles'][0];
              array_push($findrolearray,$findrole);
          }*/
        $role=$query[0]['roles'][0];
        if($role=='ROLE_SUPER_ADMIN')
        {
            $userDetails = $em->getRepository('InitialShippingBundle:CompanyDetails')->findAll();

            return $this->render('InitialShippingBundle:CompanyUsers:index1.html.twig', array(
                'shipDetails' => $userDetails,
            ));

        }

        $companyid = $em->createQueryBuilder()
            ->select('a.id')
            ->from('InitialShippingBundle:CompanyDetails','a')
            ->leftjoin('InitialShippingBundle:User','b','WITH','a.adminName = b.username')
            ->where('b.id = :userId')
            ->setParameter('userId',$userId)
            ->getQuery()
            ->getSingleScalarResult();


        $userdetails = $em->getRepository('InitialShippingBundle:User')->findBy(array('companyid' => $companyid));





        $formFactory = $this->get('fos_user.registration.form.factory');
        /** @var $userManager \FOS\UserBundle\Model\UserManagerInterface */
        $userManager = $this->get('fos_user.user_manager');
        /** @var $dispatcher \Symfony\Component\EventDispatcher\EventDispatcherInterface */
        $dispatcher = $this->get('event_dispatcher');

        $user = $userManager->createUser();
        $user->setEnabled(true);

        $event = new GetResponseUserEvent($user, $request);
        $dispatcher->dispatch(FOSUserEvents::REGISTRATION_INITIALIZE, $event);

        if (null !== $event->getResponse()) {
            return $event->getResponse();
        }

        $form = $formFactory->createForm();
        $form->setData($user);

        $editForm = $this->createForm(new RegistrationFormType(), $user);
        $editForm->handleRequest($request);

        //$userdetails = $query->getResult();

        //$form = $this->createForm(new RegistrationFormType($userId,$role), $userdetails);
        //$form->handleRequest($request);

        $count = count($userdetails);

        return $this->render('InitialShippingBundle:CompanyUsers:listall.html.twig', array(
            'userdetails' => $userdetails,
            'form' => $form->createView(),
            'user_count' => $count,
            // 'userdetails' => $user,
            'edit_form' => $editForm->createView(),

        ));
        } else {
            return $this->redirectToRoute('fos_user_security_login');
        }
    }


    public function sampleAction(Request $request)
    {
        $user = $this->getUser();
        if ($user != null) {
        $id = $request->request->get('Id');
        $em = $this->getDoctrine()->getManager();
        $query = $em->createQueryBuilder()
            ->select('a.id','a.username','a.email','a.roles','a.mobile','a.fullname')
            ->from('InitialShippingBundle:User','a')
            ->where('a.id = :user_Id')
            ->setParameter('user_Id',$id)
            ->getQuery();
        $Userdetail = $query->getResult();

        $user1 = $this->getUser();
        $userId = $user1->getId();


        $response = new JsonResponse();
        $response->setData(array(
            'User_detail' => $Userdetail,



        ));
        return $response;
        } else {
            return $this->redirectToRoute('fos_user_security_login');
        }

    }



    public function sample_editAction(Request $request)
    {
        $user = $this->getUser();
        if ($user != null) {
        $id = $request->request->get('Id');

        $em = $this->getDoctrine()->getManager();
        $userManager = $this->get('fos_user.user_manager');

        $user = $this->getDoctrine()->getManager()->getRepository('InitialShippingBundle:User')->findOneBy(array('id'=>$id));
        $userName = $request->request->get('name');
        $Email = $request->request->get('email');
        $mobile =$request->request->get('mobile');
        $fullname =$request->request->get('fullname');
        $roles =$request->request->get('privileges');



        $uservalue = new User();

        $user->setRoles(array($roles));
        $user->setemail($Email);
        $user->setusername($userName);
        $user->setmobile($mobile);
        $user->setfullname($fullname);

        //$em->persist($user);
        $em->flush();

        $userManager->updateUser($user);



        $show_response = $this->sampleAction($request);

        return $show_response;
        } else {
            return $this->redirectToRoute('fos_user_security_login');
        }




    }



    /**
     * Tell the user to check his email provider
     */
    public function checkEmailAction()
    {
        $email = $this->get('session')->get('fos_user_send_confirmation_email/email');
        $this->get('session')->remove('fos_user_send_confirmation_email/email');
        $user = $this->get('fos_user.user_manager')->findUserByEmail($email);

        if (null === $user) {
            throw new NotFoundHttpException(sprintf('The user with email "%s" does not exist', $email));
        }

        return $this->render('FOSUserBundle:Registration:checkEmail.html.twig', array(
            'user' => $user,
        ));
    }

    /**
     * Receive the confirmation token from user email provider, login the user
     */
    public function confirmAction(Request $request, $token)
    {
        /** @var $userManager \FOS\UserBundle\Model\UserManagerInterface */
        $userManager = $this->get('fos_user.user_manager');

        $user = $userManager->findUserByConfirmationToken($token);

        if (null === $user) {
            throw new NotFoundHttpException(sprintf('The user with confirmation token "%s" does not exist', $token));
        }

        /** @var $dispatcher \Symfony\Component\EventDispatcher\EventDispatcherInterface */
        $dispatcher = $this->get('event_dispatcher');

        $user->setConfirmationToken(null);
        $user->setEnabled(true);

        $event = new GetResponseUserEvent($user, $request);
        $dispatcher->dispatch(FOSUserEvents::REGISTRATION_CONFIRM, $event);

        $userManager->updateUser($user);

        if (null === $response = $event->getResponse()) {
            $url = $this->generateUrl('fos_user_registration_confirmed');
            $response = new RedirectResponse($url);
        }

        $dispatcher->dispatch(FOSUserEvents::REGISTRATION_CONFIRMED, new FilterUserResponseEvent($user, $request, $response));

        return $response;
    }

    /**
     * Tell the user his account is now confirmed
     */
    public function confirmedAction()
    {
        $user = $this->getUser();
        if (!is_object($user) || !$user instanceof UserInterface) {
            throw new AccessDeniedException('This user does not have access to this section.');
        }

        return $this->render('FOSUserBundle:Registration:confirmed.html.twig', array(
            'user' => $user,
            'targetUrl' => $this->getTargetUrlFromSession(),
        ));
    }

    private function getTargetUrlFromSession()
    {
        // Set the SecurityContext for Symfony <2.6
        if (interface_exists('Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface')) {
            $tokenStorage = $this->get('security.token_storage');
        } else {
            $tokenStorage = $this->get('security.context');
        }

        $key = sprintf('_security.%s.target_path', $tokenStorage->getToken()->getProviderKey());

        if ($this->get('session')->has($key)) {
            return $this->get('session')->get($key);
        }
    }
}